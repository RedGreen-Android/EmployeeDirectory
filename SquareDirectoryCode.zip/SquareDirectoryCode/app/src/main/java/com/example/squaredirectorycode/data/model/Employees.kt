package com.example.squaredirectorycode.data.model

data class Employees(
    val employees: List<EmployeeX>
)