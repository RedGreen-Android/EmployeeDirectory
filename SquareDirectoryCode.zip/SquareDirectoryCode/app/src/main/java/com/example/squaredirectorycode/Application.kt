package com.example.squaredirectorycode

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class Application :Application() {
}